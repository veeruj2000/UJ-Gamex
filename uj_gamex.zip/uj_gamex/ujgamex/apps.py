from django.apps import AppConfig


class UjgamexConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ujgamex'
